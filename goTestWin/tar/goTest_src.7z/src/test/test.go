
package main

import (
	"fmt"
)

func add(a int, b int) int {
	return a+b
}

func test() {
	c := add(3, 4)
	fmt.Printf("c=%d \n", c)
}

//func swap(a &int, b &int) int { //error
func swap(a *int, b *int) int {
	temp := *a
	*a = *b
	*b = temp
	return 0
}

func test2() {
	a := 10
	b := 8
	fmt.Printf("a=%d, b=%d \n", a, b)

	swap(&a, &b)
	fmt.Printf("a=%d, b=%d \n", a, b)
}

func add_self(a int) {
	fmt.Printf("a=%d \n", a)
	a++
}

func test4() {
}

func test3() {
	a := 10
	add_self(a)
	fmt.Printf("a=%d \n", a)
}

func main() {
	fmt.Println("Hello")

	//test()
	//test2()
	test3()
	test4()
}
